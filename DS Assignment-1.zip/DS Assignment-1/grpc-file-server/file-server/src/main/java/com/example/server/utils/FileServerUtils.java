package com.example.server.utils;

import com.google.protobuf.Timestamp;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;

public class FileServerUtils {

    private static final String UPLOADS_FOLDER = "/Users/divya/Desktop/server/";

    public static boolean uploadFile(com.example.files.UploadFileRequest uploadFileRequest){
        File newFile = new File(UPLOADS_FOLDER + uploadFileRequest.getDirectory() + "/" + uploadFileRequest.getFileName());
        if(!newFile.exists()) {
            boolean isDirectoryCreated = newFile.getParentFile().mkdirs();
            return writeToFile(uploadFileRequest, newFile);
        }
        return writeToFile(uploadFileRequest, newFile);
    }

    public static boolean deleteFile(com.example.files.DeleteFileRequest deleteFileRequest){
        File toBeDeleted = new File(UPLOADS_FOLDER + deleteFileRequest.getDirectory() + "/" + deleteFileRequest.getFileName());
        if(toBeDeleted.exists()){
            return toBeDeleted.delete();
        }
        return false;
    }

    public static boolean renameFile(com.example.files.RenameFileRequest renameFileRequest){
        File toBeRenamed = new File(UPLOADS_FOLDER + renameFileRequest.getDirectory() + "/" + renameFileRequest.getFromFileName());
        if(toBeRenamed.exists()){
           return toBeRenamed.renameTo(new File(UPLOADS_FOLDER + renameFileRequest.getDirectory() + "/" + renameFileRequest.getToFileName()));
        }
        return false;
    }

    public static byte[] downloadFile(com.example.files.DownloadFileRequest downloadFileRequest){
        return readBytes(downloadFileRequest);
    }

    public static com.example.files.FileMetaDataResponse getFileMetadata(com.example.files.FileMetaDataRequest fileMetaDataRequest) throws IOException {
        File file = new File(UPLOADS_FOLDER + fileMetaDataRequest.getDirectory() + "/" + fileMetaDataRequest.getFileName());
        if(file.exists()){
            Path p = Paths.get(file.getAbsolutePath());
            BasicFileAttributes view
                    = Files.getFileAttributeView(p, BasicFileAttributeView.class)
                    .readAttributes();
            FileTime fileTime=view.creationTime();
            com.example.files.FileMetaDataResponse fileMetaDataResponse = com.example.files.FileMetaDataResponse.newBuilder()
                    .setName(fileMetaDataRequest.getFileName())
                    .setDateModified(Timestamp.newBuilder().setSeconds(fileTime.toInstant().getEpochSecond()).setNanos(0).build()).build();
            return fileMetaDataResponse;
        }
        return null;
    }

    private static boolean writeToFile(com.example.files.UploadFileRequest uploadFileRequest, File file){
        InputStream is = new ByteArrayInputStream(uploadFileRequest.getPayload().toByteArray());
        try(FileOutputStream fos = new FileOutputStream(file, false)){
            int read;
            int defaultBufferSiize = 8192;
            byte[] bytes = new byte[defaultBufferSiize];
            while ((read = is.read(bytes)) != -1){
                fos.write(bytes, 0, read);
            }
        }catch (Exception ex){
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    private static byte[] readBytes(com.example.files.DownloadFileRequest downloadFileRequest){
        try{
            File file = new File(UPLOADS_FOLDER + downloadFileRequest.getDirectory() + "/" + downloadFileRequest.getFileName());
            if(file.exists()){
                byte[] content = new byte[(int)file.length()];
                BufferedInputStream input = new BufferedInputStream(new FileInputStream(file));
                input.read(content, 0, content.length);
                input.close();
                return content;
            }
            throw new FileNotFoundException(downloadFileRequest.getFileName());
        }catch (FileNotFoundException ex){
            System.out.println("File not found "+ downloadFileRequest.getFileName());
            return null;
        }
        catch (Exception ex){
            System.out.println("Exception in reading "+ downloadFileRequest.getFileName());
            return null;
        }
    }
}
