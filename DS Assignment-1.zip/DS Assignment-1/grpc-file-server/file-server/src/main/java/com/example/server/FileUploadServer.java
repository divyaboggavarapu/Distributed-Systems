package com.example.server;

import com.example.files.DownloadFileRequest;
import com.example.files.DownloadFileResponse;
import com.example.files.FileMetaDataRequest;
import com.example.files.FileMetaDataResponse;
import com.example.server.utils.FileServerUtils;
import com.google.protobuf.ByteString;
import io.grpc.stub.StreamObserver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FileUploadServer extends com.example.files.FileUploadServiceGrpc.FileUploadServiceImplBase {

    @Override
    public void getFileMetadata(FileMetaDataRequest request, StreamObserver<FileMetaDataResponse> responseObserver) {
        try {
            FileMetaDataResponse fileMetaDataResponse = FileServerUtils.getFileMetadata(request);
            responseObserver.onNext(fileMetaDataResponse);
            responseObserver.onCompleted();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void downloadFile(DownloadFileRequest request, StreamObserver<DownloadFileResponse> responseObserver) {
        DownloadFileResponse downloadFileResponse = com.example.files.DownloadFileResponse.newBuilder()
                .setFileName(request.getFileName()).setContent(ByteString.copyFrom(FileServerUtils.downloadFile(request))).build();

        responseObserver.onNext(downloadFileResponse);
        responseObserver.onCompleted();
    }

    @Override
    public void renameFile(com.example.files.RenameFileRequest request, StreamObserver<com.example.files.RenameFileResponse> responseObserver) {
        com.example.files.RenameFileResponse renameFileResponse = com.example.files.RenameFileResponse.newBuilder()
                .setDirectory(request.getDirectory()).setFromFileName(request.getFromFileName()).setToFileName(request.getToFileName())
                .setRenameResult(FileServerUtils.renameFile(request)).build();

        responseObserver.onNext(renameFileResponse);
        responseObserver.onCompleted();
    }

    @Override
    public void deleteFile(com.example.files.DeleteFileRequest request, StreamObserver<com.example.files.DeleteFileResponse> responseObserver) {
        com.example.files.DeleteFileResponse deleteFileResponse = com.example.files.DeleteFileResponse.newBuilder()
                .setFileName(request.getFileName()).setDirectory(request.getDirectory()).setDeleteResult(FileServerUtils.deleteFile(request))
                .build();
        responseObserver.onNext(deleteFileResponse);
        responseObserver.onCompleted();
    }

    @Override
    public void uploadFile(com.example.files.UploadFileRequest request, StreamObserver<com.example.files.UploadFileResponse> responseObserver) {

        com.example.files.UploadFileResponse uploadFileResponse = com.example.files.UploadFileResponse.newBuilder()
                .setFileName(request.getFileName())
                .setDirectory(request.getDirectory())
                .setUploadResult(FileServerUtils.uploadFile(request))
                .build();

        responseObserver.onNext(uploadFileResponse);
        responseObserver.onCompleted();
    }

    @Override
    public void add(com.example.files.AddInputRequest request, StreamObserver<com.example.files.AddInputRespose> responseObserver) {
        com.example.files.AddInputRespose respose = com.example.files.AddInputRespose.newBuilder()
                .setResult(request.getI() + request.getJ()).build();

        responseObserver.onNext(respose);
        responseObserver.onCompleted();
    }

    @Override
    public void sort(com.example.files.SortInputRequest request, StreamObserver<com.example.files.SortInputResponse> responseObserver) {
        List<Integer> unsorted = request.getInputList();
        List<Integer> needToSort = new ArrayList<>(unsorted);
        Collections.sort(needToSort);
        com.example.files.SortInputResponse.Builder responseBuilder = com.example.files.SortInputResponse.newBuilder();
        for (Integer each: needToSort){
            responseBuilder.addOutput(each);
        }
        com.example.files.SortInputResponse response = responseBuilder.build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}
