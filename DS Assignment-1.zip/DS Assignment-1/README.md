
# GRPC File Server

This program is to implement a simple file upload and download service and a computation service using remote procedure call (RPC) based communication.
This file server supports four basic operations: UPLOAD, DOWNLOAD, DELETE, and RENAME a file, add(i, j) and sort(array A) using synchronous, asynchronous RPCs.
In synchronous RPC, the client makes the RPC call and waits for the result from the server. In asynchronous RPC, the client makes the RPC call and waits for an acknowledgment from the server, and continues after receiving an acknowledgment.
On the other hand, after completing the computation the server sends the result of the call back to the client.

The file transfer between the client and the server made transparent to users and automatically handled by a helper thread. 
This creates a Dropbox-like synchronized storage service.
Whenever changes are made to the synchronized folder at the client side, e.g., creating a new file, updating a file, or deleting a file, the helper thread will establish a connection with the server and automatically send the corresponding operation to the server to update the folder at the server side.
We configured the helper thread to periodically check if there are changes made to the synchronized folder.
If the last update time to a file is later than the last check, the file will be synchronized. To simplify the design, we didn't consider incremental updates. Thus, if the content of a file is updated, the entire file should be sent to the server to overwrite the original copy at the server.



## Acknowledgements

This project is developed by Divya Boggavarapu(1002086719) and Abhishek Reddy Yaramala(1002072996).
## Requirements
- Java 17
- Maven 17
- IntelliJ 

## Detailed Instructions to Execute Code
- Reload the Whole Project
- Clean and compile using mvn commands or maven window in IntelliJ
- Create Server and Client two directories in your local machine.
- Change the Server directory Folder Path in ~/File-Client/src/main/java/com.example/client/oberver/FileObserver.java at line:24
- Change the Client directory Folder Path in ~/File-Server/src/main/java/com.example/server/utils/FileServerUtils.java at line:16
- Change the Download directory Folder Path to respective Path from you machine in  ~/File-Client/src/main/java/com.example/client/AsynchronousFileUploadClient.java at WriteBytes Method line:143
- Change the Download directory Folder Path to respective Path from you machine in  ~/File-Client/src/main/java/com.example/client/synchronousFileUploadClient.java at WriteBytes Method line:138
- Right Click on FileServer.java and FileClient.java and run Server and Client JVMs in mvn
- As soon as we run, FileObserver.java starts helper thread to automaticaly synchronize the files and we can experience dropbox like File system which automatically updates any modifications to files in client to files in server.

# Synchronous Commands
Create configurations for Upload, Rename, Delete, Download, Delete, Add and Sort in maven. 
Directrory is <com.example.client.FileUploadClientTester> and commands are as following:
- For Upload : 0 UPLOAD <Directory> <file name> <folder name>
- For Rename : 0 RENAME <Folder Name> <From file name> <To File Name>
- For Download: 0 DOWNLOAD <Folder Name> <FileName>
- For Delete : 0 DELETE  <Folder Name> <FileName>
- For Add: 0 ADD / / /
- For Sort: 0 SORT / / /

# Asynchronous Commands
Create configurations for Upload, Rename, Delete, Download, Delete, Add and Sort in maven. 
Directrory is <com.example.client.FileUploadClientTester> and commands are as following:
- For Upload : 1 UPLOAD <Directory> <file name> <folder name>
- For Rename : 1 RENAME <Folder Name> <From file name> <To File Name>
- For Download: 1 DOWNLOAD <Folder Name> <FileName>
- For Delete : 1 DELETE  <Folder Name> <FileName>
- For Add: 1 ADD / / /
- For Sort: 1 SORT / / /

# Sending Instructions from the Client to the Server
- To run client and Server in different machines. Please give the IP address of Server machine in ~/File-Client/src/main/java/com.example/client/AsynchronousFileUploadClient.java line: 22 and ~/File-Client/src/main/java/com.example/client/SynchronousFileUploadClient.java line:18 and run above commands
